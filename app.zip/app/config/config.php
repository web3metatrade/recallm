<?php
// FILE: /app/config/config.php

return [
    'db_host' => 'localhost',
    'db_name' => 'epezmgda_vlaherna_lucrare',
    'db_user' => 'YOUR_DB_USER',
    'db_pass' => 'YOUR_DB_PASS',
    'db_charset' => 'utf8mb4'
];
