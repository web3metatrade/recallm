<?php
$jsVer = file_exists(__DIR__ . '/pwa.js') ? filemtime(__DIR__ . '/pwa.js') : time();
?>
</div><!-- /.container -->

<footer class="bg-primary text-white mt-auto py-3">
  <div class="container text-center">&copy; <?= date('Y') ?> Vlaherna. Toate drepturile rezervate.</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/pwa.js?v=<?= $jsVer ?>"></script>
</body>
</html>
