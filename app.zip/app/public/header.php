<?php
/* version-stamp assets that really live in THIS folder */
$cssVer = file_exists(__DIR__ . '/pwa.css') ? filemtime(__DIR__ . '/pwa.css') : time();
?>
<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Vlaherna</title>

  <!-- PWA basics -->
  <link rel="manifest" href="/manifest.json">
  <meta name="theme-color" content="#007bff">

  <link rel="icon" type="image/png" sizes="192x192" href="/icons/android/android-launchericon-192-192.png">
  <link rel="apple-touch-icon" sizes="180x180" href="/icons/ios/180.png">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="/pwa.css?v=<?= $cssVer ?>">

  <!-- SW + capture beforeinstallprompt ASAP -->
  <script>
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js');

    /* hold the prompt so we can trigger it later */
    window.__deferredPWAInstallPrompt = null;
    window.addEventListener('beforeinstallprompt', e => {
      e.preventDefault();
      window.__deferredPWAInstallPrompt = e;
      document.dispatchEvent(new Event('pwa-install-available'));
    });
  </script>
</head>
<body class="d-flex flex-column min-vh-100">

<div id="device-details" style="display:none"></div>

<div id="pwa-install-overlay" class="justify-content-center align-items-center" style="display:none;">
  <div class="text-center">
    <h1 class="mb-3">Instalează aplicația</h1>
    <p>Pentru cea mai bună experiență, instalează aplicația pe dispozitivul tău.<br>
       Accesul la funcționalități este disponibil doar după instalare.</p>
    <button id="pwa-install-btn" class="btn btn-lg btn-dark mt-3" style="display:none;">
      Instalează aplicația
    </button>
    <div id="pwa-ios-instructions" class="mt-4 text-secondary" style="display:none;"></div>
    <div id="pwa-android-instructions" class="mt-4 text-secondary" style="display:none;"></div>
  </div>
</div>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand" href="/">Vlaherna</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="/about">Despre</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container flex-grow-1 py-4">
