<?php include 'header.php'; ?>

<script>
  const isInstalled =
    matchMedia('(display-mode: standalone)').matches ||
    navigator.standalone ||
    document.referrer.startsWith('android-app://') ||
    localStorage.getItem('pwa_instalat') === '1';

  if (!isInstalled) location.replace('/instalare.php');
</script>

<div class="text-center">
  <h2>Bine ai venit în aplicația Vlaherna!</h2>
  <p>Ai acces la toate funcționalitățile pentru că aplicația este instalată ca PWA.</p>
</div>

<?php include 'footer.php'; ?>
