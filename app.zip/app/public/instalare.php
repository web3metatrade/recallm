<?php include 'header.php'; ?>

<script>
const isInstalled =
  matchMedia('(display-mode: standalone)').matches ||
  navigator.standalone ||
  document.referrer.startsWith('android-app://') ||
  localStorage.getItem('pwa_instalat') === '1';

if (isInstalled) {
  location.replace('/');
}
</script>

<div class="text-center">
  <h2>Instalează aplicația Vlaherna</h2>
  <p>Dacă vezi butonul <b>„Instalează aplicația”</b>, folosește-l.<br>
     În caz contrar, urmează instrucțiunile afișate pentru dispozitivul și browser-ul tău.</p>
</div>

<?php include 'footer.php'; ?>
