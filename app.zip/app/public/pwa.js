(async () => {
  const $ = id => document.getElementById(id);
  const overlay = $('pwa-install-overlay');
  const btnInstall = $('pwa-install-btn');
  const iosInstr = $('pwa-ios-instructions');
  const andInstr = $('pwa-android-instructions');

  const setMessage = msg => {
    iosInstr.style.display = andInstr.style.display = 'none';
    andInstr.innerHTML = msg;
    andInstr.style.display = 'block';
  };

  const installed = () =>
    matchMedia('(display-mode: standalone)').matches ||
    navigator.standalone ||
    document.referrer.startsWith('android-app://') ||
    localStorage.getItem('pwa_instalat') === '1';

  if (installed()) {
    overlay.remove();
    document.body.classList.remove('pwa-blocked');
    return;
  }

  /* --- Your private/incognito detection logic remains untouched here --- */
  const isPrivate = async () => {
    if (navigator.storage && navigator.storage.estimate) {
      try {
        const { quota } = await navigator.storage.estimate();
        if (quota && quota < 120_000_000) return true;
      } catch (_) {}
    }

    if (/Firefox/i.test(navigator.userAgent) && !('serviceWorker' in navigator)) return true;

    try {
      localStorage.setItem('pwa_test', '1');
      localStorage.removeItem('pwa_test');
    } catch (_) {
      return true;
    }

    return false;
  };

  if (await isPrivate()) {
    overlay.style.display = 'flex';
    btnInstall.style.display = 'none';
    setMessage("Browserul este în modul privat/incognito. Deschide într-un tab normal pentru instalare.");
    return;
  }

  if ('serviceWorker' in navigator && !navigator.serviceWorker.controller && !sessionStorage.getItem('pwa_sw_reload')) {
    navigator.serviceWorker.ready.then(() => {
      sessionStorage.setItem('pwa_sw_reload', '1');
      location.reload();
    });
    return;
  }
  sessionStorage.removeItem('pwa_sw_reload');

  let deferredPrompt = window.__deferredPWAInstallPrompt;
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredPrompt = e;
    btnInstall.style.display = 'inline-block';
  });

  if (deferredPrompt) btnInstall.style.display = 'inline-block';

  btnInstall.addEventListener('click', async () => {
    if (!deferredPrompt) return;

    deferredPrompt.prompt();
    btnInstall.style.display = 'none';
    setMessage('Te rugăm să aștepți câteva secunde în timp ce aplicația se instalează...');

    const choice = await deferredPrompt.userChoice;
    if (choice.outcome === 'accepted') {
      localStorage.setItem('pwa_instalat', '1');

      setTimeout(() => {
        if (!installed()) {
          setMessage('✅ Aplicația este instalată!<br><br>Închide acest browser și deschide aplicația direct de pe ecranul principal.');
        }
      }, 10000);
    } else {
      setMessage('Instalarea a fost anulată. Încearcă din nou.');
      btnInstall.style.display = 'inline-block';
    }

    deferredPrompt = null;
    window.__deferredPWAInstallPrompt = null;
  });

  window.addEventListener('appinstalled', () => {
    localStorage.setItem('pwa_instalat', '1');
  });

  overlay.style.display = 'flex';
  document.body.classList.add('pwa-blocked');

  if (/iPad|iPhone/i.test(navigator.userAgent)) {
    setMessage("Pe iPhone/iPad: apasă <b>Share</b> <img src='/icons/share-ios.png' style='height:1.3em;'> apoi <b>Add to Home Screen</b>.");
  } else if (/Android/i.test(navigator.userAgent)) {
    setMessage("Pe Android: din meniul <b>⋮</b> alege <b>„Instalează aplicația”</b> sau <b>„Adaugă pe ecranul principal”</b>.");
  } else {
    setMessage("Pe desktop: icon-ul <b>＋</b> din bara de adrese sau Meniu <b>⋮</b> → <b>Instalează Vlaherna</b>.");
  }

})();
