/* FILE: /app/public/sw.js */
self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => self.clients.claim());
self.addEventListener('fetch', () => {});   // benign; keeps Chrome audit green
